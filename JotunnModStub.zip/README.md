﻿# JotunnModStub
Upon building for release, this README.md is copied into the `Package` folder for thunderstore packaging. Remember to also edit the manifest.json and supply your own mod icon.

## Installation (manual)


## Features


## Changelog


## Known issues
You can find the github at:
