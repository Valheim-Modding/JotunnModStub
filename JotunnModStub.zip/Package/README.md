﻿# JotunnModStub
Upon building for release, this README.md is copied from `ProjectRoot/Package/` into `ProjectRoot/` such that the readme is displayed when the project is viewed via github. Make sure to edit the README.md inside the package directory, and not the project root as your changes will be overwritten.

## Installation (manual)


## Features


## Changelog


## Known issues
You can find the github at:
